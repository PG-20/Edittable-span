Due to CORS policy, the HTML file will not render the on the browser if it requires an external script.
Therefore, to render the HTML, you will need to start a static server.
This can be done through:

$ npm i -g static-server
*cd to directory with HTML file*
$ static-server

